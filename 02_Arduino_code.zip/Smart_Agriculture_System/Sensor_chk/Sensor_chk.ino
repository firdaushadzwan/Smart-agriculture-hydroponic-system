#include <Wire.h>
#include <DHT.h>
#include <BH1750.h>

/* ===== PIN DEFINITIONS ===== */
#define DHTPIN 4
#define DHTTYPE DHT11
#define WATER_PIN A0

/* ===== OBJECTS ===== */
DHT dht(DHTPIN, DHTTYPE);
BH1750 lightMeter;

void setup() {
  Serial.begin(9600);
  delay(1000);

  Serial.println("=== SMART AGRICULTURE SENSOR DIAGNOSTIC ===");

  /* ===== I2C INIT ===== */
  Wire.begin();

  /* ===== BH1750 TEST ===== */
  Serial.println("\n[TEST] BH1750 Light Sensor");
  if (lightMeter.begin(BH1750::CONTINUOUS_HIGH_RES_MODE)) {
    Serial.println("BH1750 detected ✅");
  } else {
    Serial.println("BH1750 NOT detected ❌");
  }

  /* ===== DHT11 TEST ===== */
  Serial.println("\n[TEST] DHT11 Sensor");
  dht.begin();
  delay(2000);   // DHT needs delay

  float t = dht.readTemperature();
  float h = dht.readHumidity();

  if (isnan(t) || isnan(h)) {
    Serial.println("DHT11 NOT responding ❌");
  } else {
    Serial.print("DHT11 OK ✅  ");
    Serial.print("Temp: ");
    Serial.print(t);
    Serial.print(" C  Humidity: ");
    Serial.print(h);
    Serial.println(" %");
  }

  /* ===== WATER LEVEL TEST ===== */
  Serial.println("\n[TEST] Water Level Sensor");
  int waterValue = analogRead(WATER_PIN);

  Serial.print("Raw ADC Value: ");
  Serial.println(waterValue);

  if (waterValue <= 10) {
    Serial.println("Water sensor DRY or not connected ⚠️");
  } else {
    Serial.println("Water sensor responding ✅");
  }

  Serial.println("\n=== DIAGNOSTIC COMPLETE ===");
}

void loop() {
  // No loop needed for diagnostics
}
