#include <Wire.h>

void setup() {
  Serial.begin(9600);
  Wire.begin();

  Serial.println("=== I2C DEVICE SCAN START ===");
}

void loop() {
  byte error;
  int deviceCount = 0;

  for (byte address = 1; address < 127; address++) {
    Wire.beginTransmission(address);
    error = Wire.endTransmission();

    if (error == 0) {
      Serial.print("I2C device found at address 0x");
      if (address < 16) Serial.print("0");
      Serial.println(address, HEX);
      deviceCount++;
    }
  }

  if (deviceCount == 0) {
    Serial.println("No I2C devices found");
  }

  Serial.println("=== SCAN COMPLETE ===\n");
  delay(5000);
}
