#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <DHT.h>

/* ---------------- Pin Definitions ---------------- */
#define DHTPIN 4
#define DHTTYPE DHT11

#define WATER_SENSOR A0

#define LED_TEMP 8
#define LED_HUM 9
#define LED_WATER 10

/* ---------------- Objects ---------------- */
DHT dht(DHTPIN, DHTTYPE);
LiquidCrystal_I2C lcd(0x27, 16, 2);

/* ---------------- Thresholds (Safe Zone) ---------------- */
float TEMP_LIMIT = 24.0;
float HUM_LIMIT = 70.0;
int WATER_LIMIT = 30;

/* ---------------- Timing ---------------- */
unsigned long lastWarningTime = 0;
bool showFirstPair = true;
const unsigned long warningInterval = 5000;

/* ---------------- Setup ---------------- */
void setup() {
  Serial.begin(9600);
  Wire.begin();

  dht.begin();
  lcd.init();
  lcd.backlight();

  pinMode(LED_TEMP, OUTPUT);
  pinMode(LED_HUM, OUTPUT);
  pinMode(LED_WATER, OUTPUT);

  lcd.setCursor(0, 0);
  lcd.print("Smart Agriculture");
  lcd.setCursor(0, 1);
  lcd.print("System Starting");
  delay(2000);
  lcd.clear();
}

/* ---------------- Loop ---------------- */
void loop() {

  /* -------- Read Sensors -------- */
  float temperature = dht.readTemperature();
  float humidity = dht.readHumidity();

  int waterRaw = analogRead(WATER_SENSOR);
  int waterPercent = map(waterRaw, 0, 1023, 0, 100);

  /* -------- Serial Monitor -------- */
  Serial.println("----- Sensor Readings -----");
  Serial.print("Temperature : ");
  Serial.print(temperature);
  Serial.println(" C");
  Serial.print("Humidity    : ");
  Serial.print(humidity);
  Serial.println(" %");
  Serial.print("Water Level : ");
  Serial.print(waterPercent);
  Serial.println(" %");
  Serial.println("---------------------------");

  /* -------- Normal LCD Display (Every 2 sec) -------- */
  lcd.setCursor(0, 0);
  lcd.print("T:");
  lcd.print(temperature, 1);
  lcd.print("C  H:");
  lcd.print(humidity, 0);
  lcd.print("% ");

  lcd.setCursor(0, 1);
  lcd.print(" W:");
  lcd.print(waterPercent);
  lcd.print("% ");

  /* -------- LED Indicators -------- */
  digitalWrite(LED_TEMP, temperature > TEMP_LIMIT);
  digitalWrite(LED_HUM, humidity > HUM_LIMIT);
  digitalWrite(LED_WATER, waterPercent < WATER_LIMIT);

  /* -------- Warning Display (Every 5 sec) -------- */
  unsigned long currentMillis = millis();

  if (currentMillis - lastWarningTime >= warningInterval) {
    lastWarningTime = currentMillis;
    showFirstPair = !showFirstPair;

    String warnings[4];
    int count = 0;

    if (temperature > TEMP_LIMIT) warnings[count++] = "Temp HIGH";
    if (humidity > HUM_LIMIT) warnings[count++] = "Hum HIGH";
    if (waterPercent < WATER_LIMIT) warnings[count++] = "Water LOW";

    if (count > 0) {
      lcd.clear();

      if (count <= 2) {
        lcd.setCursor(0, 0);
        lcd.print(warnings[0]);
        if (count == 2) {
          lcd.setCursor(0, 1);
          lcd.print(warnings[1]);
        }
      } else {
        if (showFirstPair) {
          lcd.setCursor(0, 0);
          lcd.print(warnings[0]);
          lcd.setCursor(0, 1);
          lcd.print(warnings[1]);
        } else {
          lcd.setCursor(0, 0);
          lcd.print(warnings[2]);
          lcd.setCursor(0, 1);
          lcd.print(warnings[3]);
        }
      }
    }
  }

  delay(2000);  // Normal update interval
}
